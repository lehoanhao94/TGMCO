$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})


  function ayantoggle(){
        $(".forgot").slideToggle('slow');
    }
//$(document).ready(function(){
//    $(".for-got").click(function(){
//        
//    });
//});
