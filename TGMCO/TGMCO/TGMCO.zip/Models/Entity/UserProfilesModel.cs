﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TGMCO;

namespace TGMCO.Models.Entity
{
    public class UserProfilesModel
    {
        public USER USER { get; set; }
        public USER_PROFILES USER_PROFILES { get; set; }
    }
}